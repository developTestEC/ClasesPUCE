//
//  User.swift
//  farmanet
//
//  Created by Andres Efrain Chango Macas on 5/15/21.
//

import Foundation
struct  User {
    var username: String = ""
    var password: String = ""   
}
