//
//  PharmacyDetailViewModel.swift
//  farmanet
//
//  Created by Andres Efrain Chango Macas on 5/15/21.
//

import Foundation
class PharmacyDetailViewModel{
    var detail:String
    init(detail:String) {
        self.detail = detail
    }
}
