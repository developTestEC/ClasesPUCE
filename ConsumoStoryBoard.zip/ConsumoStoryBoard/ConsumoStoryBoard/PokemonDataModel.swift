//
//  PokemonDataModel.swift
//  ConsumoServicio
//
//  Created by Andres Chango on 6/12/23.
//

import Foundation


struct PokemonDataModel: Codable {
    let name: String
    let url: String
}
